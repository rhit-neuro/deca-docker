
#ifndef __WB_EXIT_H__
#define __WB_EXIT_H__

void wb_atExit(void);

#endif /* __WB_EXIT_H__ */
